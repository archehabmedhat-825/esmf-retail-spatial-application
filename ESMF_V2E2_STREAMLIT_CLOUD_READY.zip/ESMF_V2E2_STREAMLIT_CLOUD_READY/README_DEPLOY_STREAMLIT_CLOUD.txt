ESMF V2E2 Streamlit Cloud Ready Package

Use this package for Streamlit Community Cloud deployment.

1. Create a new GitHub repository.
2. Upload the CONTENTS of this folder to the repository root.
3. In Streamlit Cloud Deploy page use:
   - Repository: https://github.com/<your-username>/<your-repo-name>
   - Branch: main
   - Main file path: app.py
4. App URL optional: choose a simple subdomain such as esmf-retail-spatial-application.
5. After the Streamlit app opens correctly, connect your custom domain later.

Do not paste https://esmf-retail-spatial-application.com into the Repository field.
That field must be a GitHub repository URL.
